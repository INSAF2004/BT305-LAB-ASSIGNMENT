import matplotlib.pyplot as plt
import numpy as np

# Load the GROMACS data, ignoring comment lines
data = np.loadtxt('energy_helix_combined.xvg', comments=['#', '@'])
time = data[:, 0]
potential = data[:, 1]
coulomb = data[:, 2]
lj = data[:, 3]

# Setup the plot to look exactly like the screenshot
plt.figure(figsize=(8, 6))
plt.plot(time, potential, label='Total Energy (P.E.)', color='#619CFF', linewidth=1)
plt.plot(time, coulomb, label='Coulomb-SR', color='#F8766D', linewidth=1)
plt.plot(time, lj, label='Lennard-Jones-SR', color='#00BA38', linewidth=1)

# Add labels, title, and grid
plt.xlabel('Time (ps)', fontsize=12)
plt.ylabel('Energy (kJ/mol)', fontsize=12)
plt.title('Energetic Parameters over 10ns MD\nAlpha Helix Simulation', loc='left', fontsize=14)
plt.grid(True, linestyle='-', alpha=0.3)

# Setup the bottom legend
plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.2), ncol=3, frameon=False, title='Metric')

# Save the high-quality image
plt.tight_layout()
plt.savefig('Alpha_Helix_Energy_Plot.png', dpi=300)
print("Success! High-quality plot saved as 'Alpha_Helix_Energy_Plot.png'")
